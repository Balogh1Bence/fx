# Change Log - Sample Bar Chart

This page contains information about changes to the 'Sample bar chart' Power BI visual.

## 3.2.0

* Added *modern tooltip* feature
* Updated dependencies

## 3.0.0

* Webpack integration
* Azure Pipelines integration
* API 2.6.0
* updated powerbi-visuals-utils, powerbi-visuals-tools 3.x.x
* d3 v5
